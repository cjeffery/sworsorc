/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Units;

import ssterrain.Race;

/**
 *
 * @author matt
 */
public class Pikeman extends LandUnit {
    public Pikeman(){
        super();
        strength = 6;
        movement = 3;
        demoralizedStrength = 3;
        ranged = false;
    }
    
    
}
