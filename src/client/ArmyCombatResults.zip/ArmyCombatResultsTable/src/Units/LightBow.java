/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Units;

import ssterrain.Race;

/**
 *
 * @author Matt
 */
public class LightBow extends LandUnit{

    public LightBow() {
        super();
        strength = 3;
        movement = 5;
        demoralizedStrength = 1;
        ranged = true;
    }
    
}
