/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Units;

/**
 *
 * @author Matt
 */
public class MediumSpear extends LandUnit{

    public MediumSpear() {
        super();
        strength = 6;
        movement = 4;
        demoralizedStrength = 3;
        ranged = false;
    }
    
    
}
