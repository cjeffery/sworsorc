/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Units;

/**
 *
 * @author Matt
 */
public class LightHorse extends LandUnit{

    public LightHorse() {
        super();
        strength = 2;
        movement = 9;
        demoralizedStrength = 1;
        ranged = false;
    }
    
}
