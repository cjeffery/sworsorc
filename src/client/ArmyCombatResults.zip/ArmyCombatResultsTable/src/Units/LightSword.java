/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Units;

/**
 *
 * @author Matt
 */
public class LightSword extends LandUnit{

    public LightSword() {
        super();
        strength = 3;
        movement = 5;
        demoralizedStrength = 1;
        ranged = false;
    }
    
    
}
