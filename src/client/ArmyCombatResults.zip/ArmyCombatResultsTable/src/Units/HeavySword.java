/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Units;

/**
 *
 * @author Matt
 */
public class HeavySword extends LandUnit{

    public HeavySword() {
        super();
        strength = 4;
        movement = 4;
        demoralizedStrength = 2;
        ranged = false;
    }
    
    
}
