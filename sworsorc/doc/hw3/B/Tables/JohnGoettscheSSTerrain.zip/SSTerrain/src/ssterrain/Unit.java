/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ssterrain;

/**
 *
 * @author John Goettsche
 * CS 383 Software Engineering
 */
public class Unit {    
    private Race race;
    private UnitType unitType;
    
    public Unit() {
        
    }
    
    public void setRace(Race newRace){
        this.race = newRace;
    }
    
    public void setUnitType(UnitType newType){
        this.unitType = newType;
    }
    
    public Race getRace(){
        return race;
    }
    
    public UnitType getUnitType(){
        return unitType;
    }
}
