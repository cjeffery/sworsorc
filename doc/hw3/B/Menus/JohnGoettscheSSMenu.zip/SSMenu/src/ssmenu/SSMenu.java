/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ssmenu;

import javax.swing.JFrame;

/**
 *
 * @author John
 */
public class SSMenu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame main = new MainFrame();
        main.setVisible(true);
        main.setSize(240, 240);
    }
    
}
